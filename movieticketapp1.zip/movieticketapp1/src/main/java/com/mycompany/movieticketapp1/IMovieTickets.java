/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.movieticketapp1;

/**
 *
 * @author User
 */
import java.util.ArrayList;
import java.util.Scanner;

public class IMovieTickets {
    
    /** Calculates total ticket sales and the top performing movie. */

    /** Adds up the monthly sales of ONE movie. */
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;
        for (int sale : movieTicketSales) {
            total += sale;
        }
        return total;
    }

    /** Returns the name of the movie with the highest total sales. */
    public String TopMovie(String[] movies, int[] totalSales) {
        int topIndex = 0; // assume first movie is best, then compare the rest
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > totalSales[topIndex]) {
                topIndex = i;
            }
        }
        return movies[topIndex];
    }
}
