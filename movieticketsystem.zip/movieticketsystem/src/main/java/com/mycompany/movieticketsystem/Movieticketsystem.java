/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.movieticketsystem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Movieticketsystem {

    public static void main(String[] args) {
        // Single-dimensional arrays
        String[] movies = {"Napoleon", "Oppenheimer"};
        String[] months = {"JAN", "FEB", "MAR"};
        int[] totals = new int[movies.length];

        // Two-dimensional array: rows = movies, columns = months
        int[][] sales = {
            {3000, 1500, 1700},   // Napoleon
            {3500, 1200, 1600}    // Oppenheimer
        };

        // Calculate total sales for each movie
        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                totals[i] += sales[i][j];
            }
        }

        // Find the top performing movie
        int topIndex = 0;
        for (int i = 1; i < totals.length; i++) {
            if (totals[i] > totals[topIndex]) {
                topIndex = i;
            }
        }

        // Display the report
        System.out.println("MOVIE TICKET SALES REPORT - 2024");
        System.out.println();

        // Month headings
        System.out.printf("%-15s", "");
        for (int j = 0; j < months.length; j++) {
            System.out.printf("%-10s", months[j]);
        }
        System.out.println();
        System.out.println("-------------------------------------------");

        // Sales per movie per month
        for (int i = 0; i < movies.length; i++) {
            System.out.printf("%-15s", movies[i]);
            for (int j = 0; j < sales[i].length; j++) {
                System.out.printf("%-10d", sales[i][j]);
            }
            System.out.println();
        }

        System.out.println();

        // Totals per movie
        for (int i = 0; i < movies.length; i++) {
            System.out.println("Total movie ticket sales for " + movies[i] + " " + totals[i]);
        }

        System.out.println();
        System.out.println("Top performing movie: " + movies[topIndex]);
    }
}
