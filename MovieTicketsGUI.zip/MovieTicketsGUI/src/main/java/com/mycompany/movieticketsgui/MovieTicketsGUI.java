/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.movieticketsgui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 processes movie tickets for a customer.
 */
public class MovieTicketsGUI extends JFrame {

    // ---------- Constants ----------
    public static final String[] MOVIES = {"Napoleon", "Oppenheimer", "Damsel"};
    public static final String REPORT_FILE = "report.txt";
    public static final String STAR_LINE = "************************************";

    // ---------- Business logic ----------
    public final IMovieTickets movieTickets = new MovieTickets();

    // ---------- GUI components  ----------
    public final JComboBox<String> movieComboBox = new JComboBox<>(MOVIES);
    public final JTextField ticketsField = new JTextField();
    public final JTextField priceField = new JTextField();
    public final JTextArea reportArea = new JTextArea();

    public MovieTicketsGUI() {
        super("MOVIE TICKETS");
        buildMenu();
        buildForm();

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(420, 430);
        setLocationRelativeTo(null);          
    }

    /** Creating the File and Tools menus. */
    public void buildMenu() {
        JMenuBar menuBar = new JMenuBar();

        // File > Exit
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));        // Q.2.3
        fileMenu.add(exitItem);

        // Tools > Process, Clear
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(e -> processTicket());    // Q.2.4
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> clearForm());          // Q.2.6
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
    }

    /**Lays out the labels, combo box, text fields and the report text area. */
    public void buildForm() {
        // 4 rows x 2 columns: label on the left, input on the right
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 15));
        formPanel.add(new JLabel("MOVIE:"));
        formPanel.add(movieComboBox);
        formPanel.add(new JLabel("NUMBER OF TICKETS:"));
        formPanel.add(ticketsField);
        formPanel.add(new JLabel("TICKET PRICE:"));
        formPanel.add(priceField);
        formPanel.add(new JLabel("TICKET REPORT:"));
        formPanel.add(new JLabel());                            // empty cell

        reportArea.setEditable(false);                          // read only text area

        JPanel content = new JPanel(new BorderLayout(0, 10));
        content.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        content.add(formPanel, BorderLayout.NORTH);
        content.add(new JScrollPane(reportArea), BorderLayout.CENTER);
        setContentPane(content);
    }

    /**Capturing the input, validates it, shows the report and saves it. */
    public void processTicket() {
        MovieTicketData data;

        // Converting the text typed by the user into numbers
        try {
            data = new MovieTicketData(
                    (String) movieComboBox.getSelectedItem(),
                    Integer.parseInt(ticketsField.getText().trim()),
                    Double.parseDouble(priceField.getText().trim()));
        } catch (NumberFormatException ex) {
            showError("Please enter numeric values for the number of tickets and the ticket price.");
            return;
        }

        // only valid data is processed
        if (!movieTickets.ValidateData(data)) {
            showError("Invalid data. A movie must be selected, and the number of tickets "
                    + "and ticket price must be greater than zero.");
            return;
        }

        double total;
        total = movieTickets.CalculateTotalTicketPrice(
                data.getNumberOfTickets(), data.getTicketPrice());

        String report = buildReport(data, total);
        reportArea.setText(report);          
        saveReport(report);                  
    }

    /** Building the report lines shown on screen and saved to the file. */
    private String buildReport(MovieTicketData data, double total) {
        return "MOVIE NAME: " + data.getMovieName() + "\n"
                + "MOVIE TICKET PRICE: R " + data.getTicketPrice() + "\n"
                + "NUMBER OF TICKETS: " + data.getNumberOfTickets() + "\n"
                + "TOTAL TICKET PRICE: R " + total;
    }

    
    public void saveReport(String report) {
        // try-with-resources closes the file automatically
        try (PrintWriter writer = new PrintWriter(new FileWriter(REPORT_FILE))) {
            writer.println("MOVIE TICKET REPORT");
            writer.println(STAR_LINE);
            writer.println(report);
            writer.println(STAR_LINE);
        } catch (IOException ex) {
            showError("The report could not be saved to " + REPORT_FILE);
        }
    }

    /** Resetting the fields and the text area to their default state. */
    public void clearForm() {
        movieComboBox.setSelectedIndex(0);
        ticketsField.setText("");
        priceField.setText("");
        reportArea.setText("");
    }

    /** Shows an error message box. */
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        // Swing components must be created on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> new MovieTicketsGUI().setVisible(true));
    }
}
